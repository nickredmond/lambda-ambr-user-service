"use strict"

const AWS = require("aws-sdk");
var MongoClient = require("mongodb").MongoClient;

let atlas_connection_uri;
let cachedDb = null;

exports.handler = (event, context, callback) => {
    var uri = process.env["MONGODB_ATLAS_CLUSTER_URI"];

    if (atlas_connection_uri != null) {
        processEvent(event, context, callback);
    }
    else {
        // atlas_connection_uri = uri;
        // console.log('the Atlas connection string is ' + atlas_connection_uri);
        // processEvent(event, context, callback);
        const kms = new AWS.KMS();
        kms.decrypt({ CiphertextBlob: new Buffer(uri, "base64") }, (err, data) => {
            if (err) {
                console.log("Decrypt error:", err);
                return callback(err);
            }
            atlas_connection_uri = data.Plaintext.toString("ascii");
            processEvent(event, context, callback);
        });
    }
};

function processEvent(event, context, callback) {
    console.log("calling Atlas from Lambda with event: " + JSON.stringify(event));
    var query = JSON.parse(JSON.stringify(event));
    context.callbackWaitsForEmptyEventLoop = false;

    try {
        if (cachedDb == null) {
            console.log("=> connecting to database");
            MongoClient.connect(atlas_connection_uri, function(err, client) {
                cachedDb = client.db("ambr");
                return queryCharities(cachedDb, query, callback);
            });
        }
        else {
            queryCharities(cachedDb, query, callback);
        }
    }
    catch (err) {
        console.error("an error occurred", err);
    }
}

function queryCharities(db, query, callback) {
    db.collection("charities").find({}).toArray(function(err, result) {
        if (err != null) {
            console.error("error occurred in queryCharities", err);
            callback(null, JSON.stringify(err));
        }
        else {
            console.log("SUCCESS. found charities.");
            const queryText = query.text.toLowerCase();
            const queryResult = result.filter((charity) => {
                // TODO: add description to query, weight results based on name(1), keywords(2), description(3)
                return charity.name.toLowerCase().includes(queryText) || charity.keywords.includes(queryText);
            });
            callback(null, queryResult);
        }
    });
}